# Lӧb's Theorem: A functional pearl of dependently typed quining
A write-up of https://github.com/JasonGross/lob

[The Current Draft (.pdf)](//jasongross.github.io/lob-paper/nightly/lob.pdf)

[The Current Draft (.pdf, preprint)](//jasongross.github.io/lob-paper/nightly/lob-preprint.pdf)

[The Current Draft (.html)](//jasongross.github.io/lob-paper/nightly/html/lob.html)

[The construction of a quine (.html)](//jasongross.github.io/lob-paper/nightly/html/lob-build-quine.html)

[An anonymized README describing a bit of the code structure in the repo.](README-SUPPLEMENTAL.md)
